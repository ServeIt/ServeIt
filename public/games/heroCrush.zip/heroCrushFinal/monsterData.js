var monsterData = [
	{
		"level" : 1,
		"name" : "Crazy Rabbit",
		"spritesheet" : "rabbit",
		"hpRate" : 1,
		"damageRate" : 2,
		"normal" : [0,11,10],
		"attack" : [13,21,8],
		"hurt" : [12,12,1],
		"attackFx" : 'bunnyAttack',
		"hurtFx" : 'bunnyHurt'
	}
];